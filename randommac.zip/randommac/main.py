import subprocess
import random

a=00
b=random.randint(10,20)
c=random.randint(17,27)
d=random.randint(20,36)
e=random.randint(19,39)
f=random.randint(40,55)

print("Mac Changer started")

subprocess.call(["ifconfig","eth0","down"])
subprocess.call(["ifconfig","eth0","hw","ether",f"{a}:{b}:{c}:{d}:{e}:{f}"])
subprocess.call(["ifconfig","eth0","up"])
subprocess.call(["ifconfig","eth0"])
